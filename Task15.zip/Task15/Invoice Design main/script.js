async function generatePDF() {
    const { jsPDF } = window.jspdf;
    
    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.setFontSize(12);
   

    doc.save(`invoice_${invoiceNumber}.pdf`);
}
